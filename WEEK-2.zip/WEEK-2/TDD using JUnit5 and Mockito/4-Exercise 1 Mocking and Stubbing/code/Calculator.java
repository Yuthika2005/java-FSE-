public interface Calculator {
    double add(double a, double b);
}
